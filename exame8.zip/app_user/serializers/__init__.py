from .auth_serializers import *
from .student_serializers import *
from .teacher_serializers import *
from .attendance_serializers import *
from .group_serializers import *
from .common_serializers import *