from .auth_view import *
from .student_view import *
from .teacher_view import *
from .attendance_view import *
from .group_view import *
from .common_view import *
