from .auth import *
from .student import *
from .teacher import *
from .attendance import *
from .group import *
from .homework import *